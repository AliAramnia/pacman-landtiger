#include "LPC17xx.h"
#include "led/led.h"
#include "joystick/joystick.h"
#include "RIT/RIT.h"
#include "GLCD/GLCD.h" 
#include <stdio.h>
#include "Timer/timer.h"
#include <stdlib.h>
#include <time.h>
#include "Button/button.h"
#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif
typedef enum {
    UP,
    DOWN,
    LEFT,
    RIGHT,
    STOP
} Direction;
typedef enum {
    Pause,
    Resume,
		Victory,
		Over
} State;
void init_drawing(void);
void print_remaining_lives(void);
void print_CountDown(void);
void print_Score(void);
uint32_t random(uint32_t max);
void placePowerPills();
void update_display(int position,uint8_t ch);
void PacMan_move(Direction Dir);
void pause_game(void);
void Victory_game(void);
void Over_game(void);
#define ROWS 17
#define COLS 30
#define new_life 500
#define Victory_point 700		//2640
// Map representation
//     ##############################  
//     #............##..............#  
//     #.####.#####....#####.######.#  
//     #....#.#...#....#...#.#....#.#  
//     #.##.#.#.#.#....#.#.#.#.##.#.#  
//     #.##.#.#.#.#.##.#.#.#.#.##.#.#  
//     #...........    .............|  //180 //209
//     ####.######  P  #######.####.#  
//     |.......... #-# ...........#.# //240  
//     #.###.#.### ### ##.###.#.#.#.#  
//     #.#...#.###......#.###.#.#.#.#  
//     #...........#.##.............#  
//     #.####.##############.####.#.#  
//     #.###........##........###.#.#  
//     #.....#####.####.#.###.....#.#  
//     #####..................###...#  
//     ##############################  
uint8_t pacmanMap[ROWS * COLS] = {
    '#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#',
    '#','.','.','.','.','.','.','.','.','.','.','.','.','#','#','.','.','.','.','.','.','.','.','.','.','.','.','.','.','#',
    '#','.','#','#','#','#','.','#','#','#','#','#','.','.','.','.','#','#','#','#','#','.','#','#','#','#','#','#','.','#',
    '#','.','.','.','.','#','.','#','.','.','.','#','.','.','.','.','#','.','.','.','#','.','#','.','.','.','.','#','.','#',
    '#','.','#','#','.','#','.','#','.','#','.','#','.','.','.','.','#','.','#','.','#','.','#','.','#','#','.','#','.','#',
    '#','.','#','#','.','#','.','#','.','#','.','#','.','#','#','.','#','.','#','.','#','.','#','.','#','#','.','#','.','#',
    '#','.','.','.','.','.','.','.','.','.','.','.',' ',' ',' ',' ','.','.','.','.','.','.','.','.','.','.','.','.','.','|',
    '#','#','#','#','.','#','#','#','#','#','#',' ',' ','P',' ',' ','#','#','#','#','#','#','#','.','#','#','#','#','.','#',
    '|','.','.','.','.','.','.','.','.','.','.',' ','#','-','#',' ','.','.','.','.','.','.','.','.','.','.','.','#','.','#',
    '#','.','#','#','#','.','#','.','#','#','#',' ','#','#','#',' ','#','#','.','#','#','#','.','#','.','#','.','#','.','#',
    '#','.','#','.','.','.','#','.','#','#','#','.','.','.','.','.','.','#','.','#','#','#','.','#','.','#','.','#','.','#',
    '#','.','.','.','.','.','.','.','.','.','.','.','#','.','#','#','.','.','.','.','.','.','.','.','.','.','.','.','.','#',
    '#','.','#','#','#','#','.','#','#','#','#','#','#','#','#','#','#','#','#','#','#','.','#','#','#','#','.','#','.','#',
    '#','.','#','#','#','.','.','.','.','.','.','.','.','#','#','.','.','.','.','.','.','.','.','#','#','#','.','#','.','#',
    '#','.','.','.','.','.','#','#','#','#','#','.','#','#','#','#','.','#','.','#','#','#','.','.','.','.','.','#','.','#',
    '#','#','#','#','#','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','#','#','#','.','.','.','#',
    '#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#',
};
char Remaining_lives = 1;
char CountDown = 60;
int  Score = 0;
int tmp_score = 0;
char POWER_PILLS = 6;

Direction PacMan_dir = STOP;
int PacMan_pos = 0;

State Status = Resume;
int main(){
	SystemInit();
	BUTTON_init();
	for(int i=0;i<ROWS * COLS;i++){
		if(pacmanMap[i] == 'P'){PacMan_pos = i;break;}
	}

	joystick_init();
	init_RIT(0x5FFF);//0x004C4B40
	init_timer(0,0xFFFFF);//0x17D7840
  LCD_Initialization();
	LCD_Clear(Black);
	init_drawing();
	enable_timer(0);
	enable_RIT();
  while (1)	
  {
		if(Status == Resume){
			PacMan_move(PacMan_dir);
		}
		
  }
}

//xy
//font size is 8*16
//240*320
//240/8 = 30 X
//320/16 = 20 Y
void PacMan_move(Direction Dir){
	int tmp_pos = 0;
	switch (Dir) {
		case UP:
				tmp_pos = PacMan_pos - COLS;
				if(pacmanMap[tmp_pos] == '#'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '-'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '|'){
					if(tmp_pos == 240) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 208;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
					if(tmp_pos == 209) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 241;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
				}else if(pacmanMap[tmp_pos] == ' '){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
				}else if(pacmanMap[tmp_pos] == '.'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 10;
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}
				}else if(pacmanMap[tmp_pos] == '*'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 50;	
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}					
					POWER_PILLS--;
				}
				break;
		case DOWN:
				tmp_pos = PacMan_pos + COLS;
				if(pacmanMap[tmp_pos] == '#'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '-'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '|'){
					if(tmp_pos == 240) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 208;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
					if(tmp_pos == 209) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 241;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
				}else if(pacmanMap[tmp_pos] == ' '){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
				}else if(pacmanMap[tmp_pos] == '.'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 10;
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}
				}else if(pacmanMap[tmp_pos] == '*'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 50;	
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}					
					POWER_PILLS--;
				}			
				break;
		case LEFT:
				tmp_pos = PacMan_pos - 1;
				if(pacmanMap[tmp_pos] == '#'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '-'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '|'){
					if(tmp_pos == 240) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 208;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
					if(tmp_pos == 209) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 241;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
				}else if(pacmanMap[tmp_pos] == ' '){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
				}else if(pacmanMap[tmp_pos] == '.'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 10;
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}
				}else if(pacmanMap[tmp_pos] == '*'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 50;	
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}					
					POWER_PILLS--;
				}			
				break;
		case RIGHT:
				tmp_pos = PacMan_pos + 1;
				if(pacmanMap[tmp_pos] == '#'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '-'){
					PacMan_dir = STOP;
				}else if(pacmanMap[tmp_pos] == '|'){
					if(tmp_pos == 240) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 208;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
					if(tmp_pos == 209) {pacmanMap[PacMan_pos] = ' ';update_display(PacMan_pos,' ');PacMan_pos = 241;pacmanMap[PacMan_pos] = 'P';update_display(PacMan_pos,'P');}
				}else if(pacmanMap[tmp_pos] == ' '){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
				}else if(pacmanMap[tmp_pos] == '.'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 10;
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}
				}else if(pacmanMap[tmp_pos] == '*'){
					pacmanMap[tmp_pos] = 'P';
					update_display(tmp_pos,'P');
					pacmanMap[PacMan_pos] = ' ';
					update_display(PacMan_pos,' ');
					PacMan_pos = tmp_pos;
					Score += 50;	
					print_Score();
					if((Score/new_life) > tmp_score){tmp_score++;Remaining_lives++;print_remaining_lives();}					
					POWER_PILLS--;
				}		
				break;
		case STOP:
				PacMan_dir = STOP;
				break;
	}	
}



void init_drawing(void){
	LCD_Clear(Black);
  GUI_Text(0, 0,   (uint8_t *)"Game Over in", White, Black);
	print_CountDown();
	GUI_Text(144, 0, (uint8_t *)"Score", White, Black);
	print_Score();
	for(int i=0;i<ROWS;i++){
		for(int j=0;j<COLS;j++){
			uint8_t character = pacmanMap[i*30+j];
			if(character == '.')PutChar(j*8,32+(i*16),character,White,Black);
			if(character == '#')PutChar(j*8,32+(i*16),character,Blue,Black);
			if(character == '-')PutChar(j*8,32+(i*16),character,White,Black);
			if(character == 'P')PutChar(j*8,32+(i*16),character,Yellow,Black);
		}
	}
	print_remaining_lives();
	placePowerPills();	
}


void print_remaining_lives(void){
	for(int i=0;i<Remaining_lives;i++)PutChar(i*8,304,'p',Yellow,Black);
}


void print_CountDown(void){
	char buffer[4];
	sprintf(buffer, "%02d", CountDown);
	GUI_Text(32, 16, (uint8_t *)buffer, White, Black);
}

void print_Score(void){
	char buffer[5];
	sprintf(buffer, "%04d", Score);
	GUI_Text(144, 16, (uint8_t *)buffer, White, Black);
	if(Score >= Victory_point){
		Victory_game();
	}
}

uint32_t random(uint32_t max) {
    static uint32_t seed = 0; // Persistent seed variable
    if (seed == 0) {
        seed = LPC_TIM0->TC; // Initialize seed from timer only once
    }
    seed = (1103515245 * seed + 12345) & 0x7FFFFFFF;
    return seed % max;
}


void placePowerPills() {
	  for(int i=0;i<ROWS * COLS;i++){
			if(pacmanMap[i] == '*'){pacmanMap[i] = '.';update_display(i,'.');}
		}
    int pillsPlaced = 0;

    while (pillsPlaced < POWER_PILLS) {
        uint32_t randIndex = random(ROWS * COLS);
        if (pacmanMap[randIndex] == '.') {
            pacmanMap[randIndex] = '*';
						update_display(randIndex,'*');
            pillsPlaced++;
        }
    }
}





void update_display(int position,uint8_t ch){
	int i = position/COLS;
	int j = position%COLS;
	PutChar(j*8,32+(i*16),ch,Yellow,Black);
}

void pause_game(void){
	LCD_Clear(Black);
	GUI_Text(100, 152,   (uint8_t *)"Pause", White, Black);
}

void Resume_game(void){
	LCD_Clear(Black);
  GUI_Text(0, 0,   (uint8_t *)"Game Over in", White, Black);
	print_CountDown();
	GUI_Text(144, 0, (uint8_t *)"Score", White, Black);
	print_Score();
	for(int i=0;i<ROWS;i++){
		for(int j=0;j<COLS;j++){
			uint8_t character = pacmanMap[i*30+j];
			if(character == '.')PutChar(j*8,32+(i*16),character,White,Black);
			if(character == '#')PutChar(j*8,32+(i*16),character,Blue,Black);
			if(character == '-')PutChar(j*8,32+(i*16),character,White,Black);
			if(character == 'P')PutChar(j*8,32+(i*16),character,Yellow,Black);
			if(character == '*')PutChar(j*8,32+(i*16),character,White,Black);
		}
	}
	print_remaining_lives();	
}

void Victory_game(void){
	Status = Victory;
	LCD_Clear(Black);
	GUI_Text(80, 152,   (uint8_t *)"Victory!!!", White, Black);
	disable_RIT();
	disable_timer(0);
	
}

void Over_game(void){
	Status = Over;
	LCD_Clear(Black);
	GUI_Text(76, 152,   (uint8_t *)"Game Over:(", White, Black);
	disable_RIT();
	disable_timer(0);
	
}